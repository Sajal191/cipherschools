export const NOTES_DATA = "notes-data";

const type = {
  NOTES_DATA,
};

export default type;
